# -*- coding: utf-8 -*-
"""
Created on Fri Sep 5 19:53:08 2025

Author: Xu
Purpose:
Step 1 of the global TP modeling workflow:
Hyperparameter tuning and iterative predictor selection
using Random Forest and cross-validation.
"""

import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from itertools import product

# ===== Path settings =====
file_path = r"E:\RF\TP\1_tuning\TP_monitor_predictor.xlsx"
output_folder = r"E:\RF\TP\1_tuning\output_hyperparameter_selection"
os.makedirs(output_folder, exist_ok=True)

# ===== Hyperparameter grid =====
param_grid = {
    'n_estimators': [500, 1000],
    'max_features': ['sqrt', 'log2'],
}

# ===== Load data =====
df = pd.read_excel(file_path)

# Target variable (Total Phosphorus concentration)
y = df.iloc[:, 0]

# Predictor variables
X_all = df.iloc[:, 1:]
features = X_all.columns.tolist()

summary_list = []
round_id = 0

# ===== Cross-validation function =====
def cross_validate_all_metrics(X, y, param_grid, cv=10):
    """
    Perform k-fold cross-validation for all parameter combinations
    and return mean and standard deviation of performance metrics.
    """
    param_combinations = list(product(*param_grid.values()))
    param_names = list(param_grid.keys())
    kf = KFold(n_splits=cv, shuffle=True, random_state=42)
    all_results = []

    for param_values in param_combinations:
        params = dict(zip(param_names, param_values))
        r2s, rmses, maes = [], [], []

        for train_idx, test_idx in kf.split(X):
            model = RandomForestRegressor(
                **params,
                max_depth=None,
                min_samples_split=2,
                min_samples_leaf=1,
                bootstrap=True,
                oob_score=False,
                random_state=42,
                n_jobs=-1
            )

            model.fit(X.iloc[train_idx], y.iloc[train_idx])
            y_pred = model.predict(X.iloc[test_idx])

            r2s.append(r2_score(y.iloc[test_idx], y_pred))
            rmses.append(np.sqrt(mean_squared_error(y.iloc[test_idx], y_pred)))
            maes.append(mean_absolute_error(y.iloc[test_idx], y_pred))

        all_results.append({
            **params,
            'R2_mean': np.mean(r2s),
            'R2_std': np.std(r2s),
            'RMSE_mean': np.mean(rmses),
            'RMSE_std': np.std(rmses),
            'MAE_mean': np.mean(maes),
            'MAE_std': np.std(maes),
        })

    return pd.DataFrame(all_results)

# ===== Main loop: iterative feature elimination =====
while True:
    round_id += 1
    X = X_all[features]

    print(f"\n====== Round {round_id}: Number of predictors = {len(features)} ======")

    # 1. Cross-validation and hyperparameter tuning (ranked by MAE)
    cv_result_df = cross_validate_all_metrics(X, y, param_grid)

    # 2. Select the best hyperparameter combination (minimum MAE)
    best_row = cv_result_df.sort_values("MAE_mean", ascending=True).iloc[0]
    best_params = {
        'n_estimators': int(best_row['n_estimators']),
        'max_features': best_row['max_features']
    }

    # 3. Train the model using the best hyperparameters
    model = RandomForestRegressor(
        **best_params,
        max_depth=None,
        min_samples_split=2,
        min_samples_leaf=1,
        bootstrap=True,
        oob_score=False,
        random_state=42,
        n_jobs=-1
    )

    model.fit(X, y)
    y_pred = model.predict(X)

    # 4. Model performance on the full dataset
    r2 = r2_score(y, y_pred)
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    mae = mean_absolute_error(y, y_pred)

    # 5. Feature importance
    importances = pd.Series(model.feature_importances_, index=features)
    sorted_importances = importances.sort_values(ascending=True)

    # 6. Remove the least important predictor
    least_feature = sorted_importances.index[0]

    # 7. Save results for this round
    save_path = os.path.join(
        output_folder,
        f"Round_{round_id}_{len(features)}_predictors.xlsx"
    )

    with pd.ExcelWriter(save_path, engine='openpyxl') as writer:
        cv_result_df.to_excel(writer, sheet_name="CV_Results", index=False)

        pd.DataFrame({
            'R2_full': [r2],
            'RMSE_full': [rmse],
            'MAE_full': [mae],
            'Number_of_predictors': [len(features)],
            'Best_n_estimators': [best_params['n_estimators']],
            'Best_max_features': [best_params['max_features']]
        }).to_excel(writer, sheet_name="Performance", index=False)

        pd.DataFrame({
            'Observed': y,
            'Predicted': y_pred,
            'Absolute_Error': np.abs(y - y_pred)
        }).to_excel(writer, sheet_name="Prediction", index=False)

        importances.sort_values(ascending=False) \
            .to_frame("Importance") \
            .to_excel(writer, sheet_name="Feature_Importance")

    print(f"✅ Best parameters: {best_params} | MAE = {mae:.3f}")
    print(f"📁 Results saved to: {save_path}")

    # 8. Summary
    summary_list.append({
        'Round': round_id,
        'Number_of_predictors': len(features),
        'Removed_predictor': least_feature,
        'R2_full': r2,
        'RMSE_full': rmse,
        'MAE_full': mae,
        'Best_parameters': str(best_params)
    })

    # 9. Stopping condition
    if len(features) <= 1:
        print("⚠️ Only one predictor remains. Feature elimination stopped.")
        break

    print(f"❌ Removing predictor: {least_feature}")
    features.remove(least_feature)

# ===== Save overall summary =====
summary_df = pd.DataFrame(summary_list)
summary_df.to_excel(
    os.path.join(output_folder, "Summary_all_rounds.xlsx"),
    index=False
)

print("\n📊 All rounds completed. Summary file saved.")
