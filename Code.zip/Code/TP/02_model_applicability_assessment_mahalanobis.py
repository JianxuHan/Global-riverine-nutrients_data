# -*- coding: utf-8 -*-
"""

Author: Xu
Step 1 of the global TP modeling workflow:
Weighted AOA (Area of Applicability) calculation for global TP predictors

Outputs:
1) Catchment_ID, Year
2) AOA_distance_weighted
3) AOA_flag_90 (inside/outside AOA, based on the 95th percentile)
4) AOA_percentile_level (six-level classification)
5) Training MD thresholds: 50%, 75%, 90%, 95%, 99%
"""

import pandas as pd
import numpy as np

# ------------------------------
# 1. Load training and global predictor datasets
train_df = pd.read_excel(r'E:\RF\TP\6AOA\TP_predictor_all.xlsx', header=0)
global_df = pd.read_excel(r'E:\RF\TP\6AOA\Global_catchment_predictors_TP.xlsx', header=0)

# Extract predictor variables (from the 4th column onward) and convert to numeric
train_X = train_df.iloc[:, 3:].apply(pd.to_numeric, errors='coerce').values
global_X_raw = global_df.iloc[:, 3:].apply(pd.to_numeric, errors='coerce')

# Remove rows with missing values in the training set
train_X = train_X[~np.isnan(train_X).any(axis=1)]

# Keep the original filtering logic for the global prediction set
global_valid_idx = ~np.isnan(global_X_raw).any(axis=1)
global_X_raw = global_X_raw[global_valid_idx].values

# First column: Catchment ID; second column: Year
global_df_valid = global_df.loc[global_valid_idx].iloc[:, :2].reset_index(drop=True)
global_df_valid.columns = ['Catchment_ID', 'Year']

# ------------------------------
# 2. Average predictors at the catchment scale (global prediction set)
catchment_ids = global_df_valid['Catchment_ID'].values
unique_catchments = np.unique(catchment_ids)

global_X_avg = []
avg_catchment_ids = []
avg_years = []

for c in unique_catchments:
    idx = np.where(catchment_ids == c)[0]
    avg_vals = np.mean(global_X_raw[idx, :], axis=0)
    global_X_avg.append(avg_vals)
    avg_catchment_ids.append(c)
    avg_years.append(int(np.mean(global_df_valid.loc[idx, 'Year'])))

global_X_avg = np.array(global_X_avg)

# ------------------------------
# 3. Compute mean vector and covariance matrix of the training set
mean_train = np.mean(train_X, axis=0)
cov_train = np.cov(train_X, rowvar=False)
cov_inv = np.linalg.pinv(cov_train)

# ------------------------------
# 4. Define predictor importance weights
weights = np.array([
    11.1, 9.1, 8.6, 8.5, 8.0,
    7.0, 6.6, 5.6, 5.5, 5.4,
    5.2, 5.1, 4.9, 4.8, 4.7
])
weights = weights / np.mean(weights)

# ------------------------------
# 5. Weighted Mahalanobis distance function
def mahalanobis_distance_weighted(X, mean, cov_inv, weights):
    diff = (X - mean) * np.sqrt(weights)
    left = np.dot(diff, cov_inv)
    md = np.sqrt(np.sum(left * diff, axis=1))
    return md

# Mahalanobis distances for the training set
md_train = mahalanobis_distance_weighted(train_X, mean_train, cov_inv, weights)

# Mahalanobis distances for global catchments
md_global = mahalanobis_distance_weighted(global_X_avg, mean_train, cov_inv, weights)

# ------------------------------
# 6. Percentile-based thresholds from the training set
q50 = np.percentile(md_train, 50)
q75 = np.percentile(md_train, 75)
q90 = np.percentile(md_train, 90)
q95 = np.percentile(md_train, 95)
q99 = np.percentile(md_train, 99)

# Inside / outside AOA defined by the 95th percentile
threshold_90 = q95

aoa_distance = md_global
aoa_flag = (aoa_distance <= threshold_90).astype(int)

# ------------------------------
# 7. Assign percentile-based extrapolation levels to each catchment
# 1 = ≤50%
# 2 = 50–75%
# 3 = 75–90%
# 4 = 90–95%
# 5 = 95–99%
# 6 = >99% (extreme extrapolation)

aoa_percentile_level = np.zeros_like(aoa_distance, dtype=int)

aoa_percentile_level[aoa_distance <= q50] = 1
aoa_percentile_level[(aoa_distance > q50) & (aoa_distance <= q75)] = 2
aoa_percentile_level[(aoa_distance > q75) & (aoa_distance <= q90)] = 3
aoa_percentile_level[(aoa_distance > q90) & (aoa_distance <= q95)] = 4
aoa_percentile_level[(aoa_distance > q95) & (aoa_distance <= q99)] = 5
aoa_percentile_level[aoa_distance > q99] = 6

# ------------------------------
# 8. Save catchment-scale AOA results with percentile levels
output_df = pd.DataFrame({
    'Catchment_ID': avg_catchment_ids,
    'Year': avg_years,
    'AOA_distance_weighted': aoa_distance,
    'AOA_flag_90': aoa_flag,
    'AOA_percentile_level': aoa_percentile_level
})

output_df.to_excel(
    r'E:\RF\TP\6AOA\Global_catchment_AOA_TP_weighted.xlsx',
    index=False
)

# ------------------------------
# 9. Save training-set percentile thresholds (for map legends)
threshold_df = pd.DataFrame({
    'Percentile': ['50%', '75%', '90%', '95%', '99%'],
    'Threshold': [q50, q75, q90, q95, q99]
})

threshold_df.to_excel(
    r'E:\RF\TP\6AOA\AOA_training_percentiles_TP_weighted.xlsx',
    index=False
)

# ------------------------------
# 10. Console output
print("Weighted AOA calculation completed.")
print("Training-set Mahalanobis distance thresholds:")
print(f"50% = {q50}")
print(f"75% = {q75}")
print(f"90% = {q90}")
print(f"95% = {q95}")
print(f"99% = {q99}")
print("Each catchment has been assigned an AOA percentile level (1–6).")
print("AOA results saved: Global_catchment_AOA_TP_weighted.xlsx")
print("Threshold table saved: AOA_training_percentiles_TP_weighted.xlsx")
