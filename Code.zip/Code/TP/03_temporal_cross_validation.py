# -*- coding: utf-8 -*-
"""

Author: Xu
Train a Random Forest model using data from 1990–2018
and evaluate temporal extrapolation using data from 2019–2023.

Step 3 of the global TP modeling workflow:
Temporal extrapolation validation.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import joblib
import os

# ========== 0. Kling–Gupta Efficiency (KGE) ==========
def kling_gupta_efficiency(sim, obs):
    """
    Calculate Kling–Gupta Efficiency (KGE).
    """
    sim = np.array(sim)
    obs = np.array(obs)

    r = np.corrcoef(sim, obs)[0, 1]
    alpha = np.std(sim) / np.std(obs)
    beta = np.mean(sim) / np.mean(obs)

    kge = 1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2)
    return kge

# ========== 1. Load data ==========
file_path = r"E:\RF\TP\2_temporal_extrapolation\TP_predictor.xlsx"
df = pd.read_excel(file_path)

# Expected structure:
# grdc_no | basin_id | year | TP | predictors...

# ========== 2. Separate target and predictors ==========
# Target variable: Total Phosphorus (TP)
y_all = df.iloc[:, 2]

# Predictor variables
X_all = df.iloc[:, 3:23]

# Year column
year_all = df['year']

# ========== 3. Split training and testing periods ==========
train_mask = year_all.between(1990, 1995)
test_mask = year_all.between(1996, 2023)

X_train = X_all[train_mask]
y_train = y_all[train_mask]

X_test = X_all[test_mask]
y_test = y_all[test_mask]

feature_cols = X_train.columns.tolist()

# ========== 4. Model training ==========
model = RandomForestRegressor(
    n_estimators=1000,
    max_depth=None,
    min_samples_split=2,
    min_samples_leaf=1,
    max_features='sqrt',
    bootstrap=True,
    oob_score=False,
    random_state=42,
    n_jobs=-1
)

model.fit(X_train, y_train)

# ========== 5. Save trained model ==========
model_save_path = r"E:\RF\TP\2_temporal_extrapolation\time_model_TP.pkl"
joblib.dump((model, feature_cols), model_save_path)

print(f"✅ Trained model and feature order saved to: {model_save_path}")

# ========== 6. Model evaluation (test period: 2019–2023) ==========
y_pred_test = model.predict(X_test)

r2_test = r2_score(y_test, y_pred_test)
rmse_test = np.sqrt(mean_squared_error(y_test, y_pred_test))
mae_test = mean_absolute_error(y_test, y_pred_test)
kge_test = kling_gupta_efficiency(y_pred_test, y_test)

print("\n===== Model performance on the 2019–2023 test period =====")
print(f"R²:   {r2_test:.4f}")
print(f"RMSE: {rmse_test:.4f}")
print(f"MAE:  {mae_test:.4f}")
print(f"KGE:  {kge_test:.4f}")

# ========== 7. Model evaluation (training period: 1990–2018) ==========
y_pred_train = model.predict(X_train)

r2_train = r2_score(y_train, y_pred_train)
rmse_train = np.sqrt(mean_squared_error(y_train, y_pred_train))
mae_train = mean_absolute_error(y_train, y_pred_train)
kge_train = kling_gupta_efficiency(y_pred_train, y_train)

print("\n===== Model performance on the 1990–2018 training period =====")
print(f"R²:   {r2_train:.4f}")
print(f"RMSE: {rmse_train:.4f}")
print(f"MAE:  {mae_train:.4f}")
print(f"KGE:  {kge_train:.4f}")

# ========== 8. Save test-period predictions ==========
results_test = df[test_mask][['grdc_no', 'year']].copy()
results_test['Observed_TP'] = y_test.values
results_test['Predicted_TP'] = y_pred_test
results_test['Absolute_Error'] = np.abs(y_test.values - y_pred_test)

results_test_path = (
    r"E:\RF\TP\2_temporal_extrapolation\"
    r"time_predictions_2019_2023.xlsx"
)
results_test.to_excel(results_test_path, index=False)

print(f"✅ Test-period predictions saved to: {results_test_path}")

# ========== 9. Save training-period predictions ==========
results_train = df[train_mask][['grdc_no', 'year']].copy()
results_train['Observed_TP'] = y_train.values
results_train['Predicted_TP'] = y_pred_train
results_train['Absolute_Error'] = np.abs(y_train.values - y_pred_train)

results_train_path = (
    r"E:\RF\TP\2_temporal_extrapolation\"
    r"time_predictions_1990_2018.xlsx"
)
results_train.to_excel(results_train_path, index=False)

print(f"✅ Training-period predictions saved to: {results_train_path}")

# ========== 10. Save feature importance ==========
importances = pd.Series(model.feature_importances_, index=feature_cols)
all_importances = importances.sort_values(ascending=False)

print("\n🌟 Top 10 most important predictors:")
print(all_importances.head(10))

importance_path = (
    r"E:\RF\TP\2_temporal_extrapolation\"
    r"time_feature_importance.xlsx"
)
all_importances.to_excel(importance_path, header=["Importance"])

print(f"✅ Feature importance saved to: {importance_path}")
