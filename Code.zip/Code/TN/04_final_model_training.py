# -*- coding: utf-8 -*-
"""
Created on Mon Jul 21 09:49:52 2025

Author: Xu

Step 4 of the global TN modeling workflow:
Training the final Random Forest model using all available data.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import joblib

# ========== 1. Load data ==========
file_path = r"E:\RF\TN\3_final_model_training\TN_predictor_all.xlsx"
df = pd.read_excel(file_path)

# Expected structure:
# id | basin_id | year | TN | predictors...

# Target variable: Total Phosphorus (TN)
y = df.iloc[:, 2]

# Predictor variables
X = df.iloc[:, 3:22]

# Preserve feature order
feature_cols = X.columns.tolist()

# ========== 2. Train final model ==========
model = RandomForestRegressor(
    n_estimators=1000,
    max_depth=None,
    min_samples_split=2,
    min_samples_leaf=1,
    max_features='sqrt',
    bootstrap=True,
    oob_score=False,
    random_state=42,
    n_jobs=-1
)

model.fit(X, y)

# ========== 3. Save model and feature order ==========
model_save_path = r"E:\RF\TN\3_final_model_training\final_model_TN.pkl"
joblib.dump((model, feature_cols), model_save_path)

print(f"✅ Final model and feature order saved to: {model_save_path}")

# ========== 4. Define Kling–Gupta Efficiency (KGE) ==========
def kge(y_true, y_pred):
    """
    Calculate Kling–Gupta Efficiency (KGE).
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)

    r = np.corrcoef(y_true, y_pred)[0, 1]
    beta = np.mean(y_pred) / np.mean(y_true)
    gamma = np.std(y_pred) / np.std(y_true)

    return 1 - np.sqrt((r - 1) ** 2 + (beta - 1) ** 2 + (gamma - 1) ** 2)

# ========== 5. Model prediction and performance evaluation ==========
y_pred = model.predict(X)

r2 = r2_score(y, y_pred)
rmse = np.sqrt(mean_squared_error(y, y_pred))
mae = mean_absolute_error(y, y_pred)
kge_val = kge(y, y_pred)

print("===== Performance of the final model trained on all data =====")
print(f"KGE:  {kge_val:.4f}")
print(f"R²:   {r2:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"MAE:  {mae:.4f}")

# ========== 6. Save predictions ==========
results = pd.DataFrame({
    'Observed_TN': y,
    'Predicted_TN': y_pred,
    'Absolute_Error': np.abs(y - y_pred)
})

results.to_excel(
    r"E:\RF\TN\3_final_model_training\final_model_predictions.xlsx",
    index=False
)

# ========== 7. Save feature importance ==========
importances = pd.Series(model.feature_importances_, index=feature_cols)
all_importances = importances.sort_values(ascending=False)

print("\n🌟 Top 10 most important predictors:")
print(all_importances.head(10))

all_importances.to_excel(
    r"E:\RF\TN\3_final_model_training\feature_importance_all_predictors.xlsx",
    header=["Importance"]
)
