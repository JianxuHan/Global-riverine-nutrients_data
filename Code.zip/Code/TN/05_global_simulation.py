# -*- coding: utf-8 -*-
"""
Created on Mon Jul 21 10:03:26 2025

Author: Xu

Step 5 of the global TN modeling workflow:
Global simulation for ungauged or unseen catchments.
Only predicted concentrations are generated and exported.
"""

import pandas as pd
import numpy as np
import joblib

# ========== 1. Load trained model and feature order ==========
model_path = r"E:\RF\TN\4_global_simulation\final_model_TN.pkl"
model, feature_cols = joblib.load(model_path)

print("✅ Trained model and feature order loaded successfully!")

# ========== 2. Define prediction-only function ==========
def predict_only(input_file, ouTNut_file, label=""):
    """
    Generate predictions for new catchments using the trained model.
    Only predicted TN concentrations are exported.
    """
    df = pd.read_excel(input_file)

    # Extract predictor variables
    feature_df = df.iloc[:, 3:]

    # Ensure consistent feature order
    X = feature_df[feature_cols]

    # Model prediction
    y_pred = model.predict(X)

    # Save prediction results
    results = df.iloc[:, [0, 1]].copy()
    results['Predicted_TN'] = y_pred

    results.to_excel(ouTNut_file, index=False)

    print(f"✅ {label} prediction completed. Results saved to: {ouTNut_file}")

# ========== 3. Global simulation dataset paths ==========
datasets = {
    "Global simulation": {
        "input": r"E:\RF\TN\4_global_simulation\global_catchment_predictors_TN.xlsx",
        "ouTNut": r"E:\RF\TN\4_global_simulation\global_catchment_predictions_TN.xlsx"
    }
}

# ========== 4. Run global simulation ==========
for label, paths in datasets.items():
    predict_only(paths["input"], paths["ouTNut"], label)
